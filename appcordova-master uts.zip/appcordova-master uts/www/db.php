<?php
 header("Access-Control-Allow-Origin: *");
 $con = mysqli_connect("localhost","bagus134955","id8241667_barang","id8241667_barang") or die ("could not connect database");
?>