<?php
 include "db.php";
 if(isset($_POST['insert']))
 {
 $id_barang=$_POST['id_barang'];
 $nama_barang=$_POST['nama_barang'];
 $harga=$_POST['harga'];
  $jumlah=$_POST['jumlah'];
 $q=mysqli_query($con,"INSERT INTO `BARANG` (`id_barang`,`nama_barang`,`harga`,`jumlah`) VALUES ('$id_barang','$nama_barang','$harga','$jumlah')");
 if($q)
  echo "success";
 else
  echo "error";
 }
 ?>