<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET,POST,PATCH,PUT,DELETE,OPTIONS");

include "db.php";

if (isset($_POST['submit'])) {
    $id_barang = $_POST['id_barang'];
    $nama_barang = $_POST['nama_barang'];
    $jumlah = $_POST['jumlah'];
    $harga = $_POST['harga'];
  

    require_once("db.php");

    $q = mysqli_query($con, "INSERT INTO `tb_BARANG` (`id_barang`,`nama_barang`,`jumlahs`,`harga`,`) VALUES ('$id_barang','$nama_barang','$jumlah','$harga',')");
    if ($q)
        echo "success";
    else
        echo "error";
}
