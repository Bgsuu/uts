<?php
 header("Access-Control-Allow-Origin: *");
 $con = mysqli_connect("localhost","id8241667_barang","bagus134955","id8241667_barang") or die ("could not connect database");
